const main = require('../assessment/static/assessment/main.js')
const PostReadCounter = main.PostReadCounter

describe('PostReadCounter', () => {
  beforeEach(() => {
    console.log = jest.fn()
  })

  test('read() method increases the read count', () => {
    const prc = new PostReadCounter('My Post')
    expect(prc.readCount).toBe(0)
    prc.read()
    expect(prc.readCount).toBe(1)
  })

  test('getDescription() method returns description with correct pluralization', () => {
    const prc = new PostReadCounter('My Post')
    expect(prc.getDescription()).toBe('My Post was read 0 times')
    prc.read()
    expect(prc.getDescription()).toBe('My Post was read 1 time')
    prc.read()
    expect(prc.getDescription()).toBe('My Post was read 2 times')
    prc.read()
  })

 test('getDescription() method returns description with correct pluralization', () => {
   const prc = new PostReadCounter('My Post')
   prc.getDescription = jest.fn().mockReturnValue('getDescriptionReturn()')
   prc.outputDescription()
    expect(console.log).toHaveBeenCalledWith('getDescriptionReturn()')
 })
})

