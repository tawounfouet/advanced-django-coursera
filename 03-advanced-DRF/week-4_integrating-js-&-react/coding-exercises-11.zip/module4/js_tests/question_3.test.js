const main = require('../assessment/static/assessment/main.js')
const React = require('react')
const renderer = require('react-test-renderer')
const ClickOnceButton = main.ClickOnceButton

describe('ClickOnceButton', () => {
  test('default rendering', () => {
    const cob = renderer.create(<ClickOnceButton/>)
    const tree = cob.toJSON()
    expect(tree.type).toBe('button')
    expect(tree.props.className).toContain('btn')
    expect(tree.props.className).toContain('btn-primary')
    expect(tree.props.disabled).toBe(false)
    expect(tree.children).toEqual(['Click Me!'])
  })

  test('rendering after click', () => {
    const cob = renderer.create(<ClickOnceButton/>)
    let tree = cob.toJSON()
    tree.props.onClick()
    tree.props.onClick() // click twice to check for toggling
    tree = cob.toJSON()
    expect(tree.type).toBe('button')
    expect(tree.props.className).toContain('btn')
    expect(tree.props.className).toContain('btn-primary')
    expect(tree.props.disabled).toBe(true)
    expect(tree.children).toEqual(['Clicked!'])
  })
})
