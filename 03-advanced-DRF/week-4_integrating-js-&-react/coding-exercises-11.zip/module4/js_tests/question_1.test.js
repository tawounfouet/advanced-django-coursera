const main = require('../assessment/static/assessment/main.js')
const sayHello = main.sayHello
const userName = main.userName

describe('sayHello function tests', () => {
  beforeEach(() => {
    console.log = jest.fn()
  })

  test('Function outputs hello name with given name', () => {
    sayHello('Billiam')
    expect(console.log).toHaveBeenCalledWith('Hello, Billiam')
  })

  test('Function outputs hello default name with not argument', () => {
    sayHello()
    expect(console.log).toHaveBeenCalledWith('Hello, ' + userName)
  })
})

