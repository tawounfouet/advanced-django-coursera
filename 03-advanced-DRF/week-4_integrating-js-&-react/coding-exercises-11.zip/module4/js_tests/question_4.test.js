const main = require('../assessment/static/assessment/main.js')
const getMockPost = main.getMockPost

describe('getMockPost', () => {
  beforeEach(() => {
    console.log = jest.fn()
  })

  test('fetching and output', async () => {
    const mockPost = {
      title: 'Post Title',
      content: 'This is some example or mock Post content.'
    }

    global.fetch = jest.fn(() =>
      Promise.resolve({
          json: () => Promise.resolve(mockPost)
        }
      )
    )

    function flushPromises () { // this just means we'll wait for all other promises in the queue to be resolved
      return new Promise(resolve => setImmediate(resolve))
    }

    getMockPost()
    await flushPromises()
    expect(console.log).toHaveBeenCalledWith(mockPost)
  })
})
