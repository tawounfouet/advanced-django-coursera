const main = require('../assessment/static/assessment/main.js')
const React = require('react')
const renderer = require('react-test-renderer')
const PostDisplay = main.PostDisplay

describe('PostDisplay', () => {
  beforeEach(() => {
    const mockPost = {
      title: 'Post Title',
      content: 'This is some example or mock Post content.'
    }

    global.fetch = jest.fn(() =>
      Promise.resolve({
          json: () => Promise.resolve(mockPost)
        }
      )
    )
  })

  test('Component rendering before fetch', async () => {
    const pd = renderer.create(<PostDisplay/>)
    const tree = pd.toJSON()
    expect(tree.type).toBe('div')
    expect(tree.children).toEqual(['Loading...'])

  })

  test('Component rendering after fetch', async () => {
    const pd = renderer.create(<PostDisplay/>)

    function flushPromises () {
      return new Promise(resolve => setImmediate(resolve))
    }

    await flushPromises()
    const tree = pd.toJSON()
    expect(tree).toMatchSnapshot()
  })
})
