from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.views import APIView

from assessment.filters import PostFilterSet
from assessment.models import Post
from assessment.serializers import PostSerializer


class PostViewSet(viewsets.ModelViewSet):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
    filterset_class = PostFilterSet

    def get_queryset(self):
        queryset = super(PostViewSet, self).get_queryset()
        if self.request.user.is_anonymous or self.request.GET.get("all") == "true":
            return queryset

        return queryset.filter(author=self.request.user)


class MockPostView(APIView):
    def get(self, request):
        return Response(
            {
                "title": "Post Title",
                "content": "This is some example or mock Post content.",
            }
        )


# No changes are required to this class
class WhoAmIView(APIView):
    def get(self, request):
        return Response(
            {"username": None if request.user.is_anonymous else request.user.username}
        )
