from django_filters import rest_framework as filters

from assessment.models import Post


class PostFilterSet(filters.FilterSet):
    content = filters.CharFilter(
        field_name="content",
        lookup_expr="icontains",
    )

    class Meta:
        model = Post
        fields = ["author", "slug"]
