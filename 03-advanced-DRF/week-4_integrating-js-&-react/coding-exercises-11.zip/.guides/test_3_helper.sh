#!/bin/bash

cd module4
npm test js_tests/question_3.test.js