from django.contrib.auth import get_user_model
from django.test import TestCase
from rest_framework.test import APIClient


class Question4TestCase(TestCase):
    def setUp(self):
        self.client = APIClient()

        self.user = get_user_model().objects.create_user(
            username="test", password="password"
        )

    def test_unauthorized_whoami(self):
        resp = self.client.get("/api/v1/whoami/")
        self.assertIsNone(resp.json()["username"])

    def test_jwt(self):
        token_resp = self.client.post(
            "/api/v1/jwt/", {"username": "test", "password": "password"}
        )
        refresh = token_resp.json().get("refresh")
        access = token_resp.json().get("access")
        self.assertIsNotNone(refresh)
        self.assertIsNotNone(access)

        self.client.credentials(HTTP_AUTHORIZATION="Bearer " + access)
        whoami_resp = self.client.get("/api/v1/whoami/")
        self.assertEqual(whoami_resp.json()["username"], "test")

        refresh_resp = self.client.post("/api/v1/jwt/refresh/", {"refresh": refresh})
        self.assertIn("access", refresh_resp.json())
