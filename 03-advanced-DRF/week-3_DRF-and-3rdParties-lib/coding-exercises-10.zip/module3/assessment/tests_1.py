from time import time
from unittest import mock

from django.contrib.auth import get_user_model
from django.test import TestCase
from rest_framework.test import APIClient

from assessment.models import Post


class Question1TestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = get_user_model().objects.create_user(
            username="test", password="password"
        )

        for i in range(20):
            Post.objects.create(
                title=f"Post {i+1}",
                content=f"Post content {i+1}",
                slug=f"post-{i+1}",
                author=self.user,
            )

    def test_pagination(self):
        resp = self.client.get("/api/v1/posts/")
        data = resp.json()
        self.assertEqual(
            [p["id"] for p in data["results"]], [p.id for p in Post.objects.all()[:10]]
        )

        resp2 = self.client.get("/api/v1/posts/?page=2")
        data2 = resp2.json()
        self.assertEqual(
            [p["id"] for p in data2["results"]], [p.id for p in Post.objects.all()[10:]]
        )
