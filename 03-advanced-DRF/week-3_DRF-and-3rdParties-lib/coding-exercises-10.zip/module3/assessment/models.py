from django.contrib.auth import get_user_model
from django.db import models
from versatileimagefield.fields import VersatileImageField


class Post(models.Model):
    title = models.TextField()
    content = models.TextField()
    slug = models.SlugField()
    author = models.ForeignKey(get_user_model(), on_delete=models.PROTECT)
    image = VersatileImageField(null=True)

    class Meta:
        ordering = ["id"]
