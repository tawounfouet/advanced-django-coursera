from django.contrib.auth import get_user_model
from django.test import TestCase
from rest_framework.test import APIClient

from assessment.models import Post


class Question3TestCase(TestCase):
    def setUp(self):
        self.client = APIClient()

        self.user = get_user_model().objects.create_user(
            username="test", password="password"
        )
        user2 = get_user_model().objects.create_user(
            username="test2", password="password"
        )

        Post.objects.create(
            title="Post 1", content="Post 1 content.", slug="post-1", author=self.user
        )
        Post.objects.create(
            title="Post 2", content="Post 2 content.", slug="post-2", author=user2
        )

    def test_content_filtering(self):
        resp = self.client.get("/api/v1/posts/?content=post 1")
        results = resp.json()["results"]
        self.assertEqual(len(results), 1)
        post = resp.json()["results"][0]
        self.assertEqual(post["slug"], "post-1")
        self.assertEqual(post["content"], "Post 1 content.")
        self.assertEqual(post["title"], "Post 1")
