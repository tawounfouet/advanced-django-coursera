from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from rest_framework.test import APIClient

from assessment.models import Post
from assessment.serializers import PostSerializer


class Question5TestCase(TestCase):
    def setUp(self):
        self.client = APIClient()

        user = get_user_model().objects.create_user(
            username="test", password="password"
        )
        with open(settings.BASE_DIR / "snake.jpg", "rb") as im:
            Post.objects.create(
                title="Title",
                content="Content",
                slug="slug",
                author=user,
                image=SimpleUploadedFile("snake.jpg", im.read()),
            )

    def test_image_field(self):
        post = self.client.get("/api/v1/posts/1/").json()
        self.assertIsInstance(post["image"], dict)
        self.assertIn("full_size", post["image"])
        self.assertIn("thumbnail", post["image"])

    def test_serializer_configuration(self):
        ps = PostSerializer()
        for name, args in ps.fields["image"].sizes:
            if name == "full_size":
                self.assertEqual(args, "url")
            elif name == "thumbnail":
                self.assertEqual(args, "thumbnail__200x200")
            else:
                raise ValueError(f"Unexpected image size name '{name}'")
