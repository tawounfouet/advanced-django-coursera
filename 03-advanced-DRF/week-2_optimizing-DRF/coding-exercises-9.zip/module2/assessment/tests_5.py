from assessment.tests_4 import Question4TestCase


class Question5TestCase(Question4TestCase):
    def test_post_endpoints_logged_in(self):
        self.client.login(username="test1", password="password")
        resp = self.client.get("/api/v1/posts/")
        self.assertEqual(len(resp.json()), 1)
        self.assertEqual(resp.json()[0]["id"], self.post1.id)
        resp = self.client.get("/api/v1/posts/?all=true")
        self.assertEqual(len(resp.json()), 2)

        detail_resp = self.client.get(f"/api/v1/posts/{self.post1.id}/")
        self.assertEqual(detail_resp.status_code, 200)

        detail_resp = self.client.get(f"/api/v1/posts/{self.post2.id}/")
        self.assertEqual(detail_resp.status_code, 404)
        detail_resp = self.client.get(f"/api/v1/posts/{self.post2.id}/?all=true")
        self.assertEqual(detail_resp.status_code, 200)

        self.client.logout()

        self.client.login(username="test2", password="password")
        resp = self.client.get("/api/v1/posts/")
        self.assertEqual(len(resp.json()), 1)
        self.assertEqual(resp.json()[0]["id"], self.post2.id)
        resp = self.client.get("/api/v1/posts/?all=true")
        self.assertEqual(len(resp.json()), 2)

        detail_resp = self.client.get(f"/api/v1/posts/{self.post1.id}/")
        self.assertEqual(detail_resp.status_code, 404)
        detail_resp = self.client.get(f"/api/v1/posts/{self.post1.id}/?all=true")
        self.assertEqual(detail_resp.status_code, 200)

        detail_resp = self.client.get(f"/api/v1/posts/{self.post2.id}/")
        self.assertEqual(detail_resp.status_code, 200)
