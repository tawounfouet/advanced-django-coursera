from time import time
from unittest import mock

from django.core.cache import cache
from django.test import TestCase
from rest_framework.test import APIClient

start_time = time()


class Question2TestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        cache.clear()

    def _run_test(self, mock_time, expected_throttle_limit):
        mock_time.return_value = start_time
        for _ in range(expected_throttle_limit):
            resp = self.client.get("/api/v1/posts/")
            self.assertEqual(resp.status_code, 200)

        resp = self.client.get("/api/v1/posts/")
        self.assertEqual(resp.status_code, 429)

        mock_time.return_value = start_time + 59

        resp = self.client.get("/api/v1/posts/")
        self.assertEqual(resp.status_code, 429)

        mock_time.return_value = start_time + 60 + 59

        resp = self.client.get("/api/v1/posts/")
        self.assertEqual(resp.status_code, 200)

    @mock.patch("time.time")
    def test_anon_throttling(self, mock_time):
        self._run_test(mock_time, 10)
