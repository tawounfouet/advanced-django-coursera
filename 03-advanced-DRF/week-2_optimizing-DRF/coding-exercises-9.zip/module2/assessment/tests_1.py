from time import time
from unittest import mock

from django.contrib.auth import get_user_model
from django.test import TestCase
from rest_framework.test import APIClient

from assessment.models import Post

start_time = time()


class Question1TestCase(TestCase):
    def setUp(self):
        self.client = APIClient()
        self.user = get_user_model().objects.create_user(
            username="test", password="password"
        )

    @mock.patch("time.time")
    def test_list_caching(self, mock_time):
        mock_time.return_value = start_time
        Post.objects.create(
            title="Post 1", content="Post 1 Content", slug="post-1", author=self.user
        )
        resp = self.client.get("/api/v1/posts/")
        Post.objects.create(
            title="Post 2", content="Post 2 Content", slug="post-2", author=self.user
        )
        resp2 = self.client.get("/api/v1/posts/")

        self.assertEqual(resp.json(), resp2.json())

        mock_time.return_value = start_time + 59
        just_before_expire_response = self.client.get("/api/v1/posts/")
        self.assertEqual(resp.json(), just_before_expire_response.json())

        mock_time.return_value = start_time + 61
        post_expire_response = self.client.get("/api/v1/posts/")
        self.assertNotEqual(resp.json(), post_expire_response.json())
        self.assertEqual(len(resp.json()), 1)
        self.assertEqual(len(post_expire_response.json()), 2)
