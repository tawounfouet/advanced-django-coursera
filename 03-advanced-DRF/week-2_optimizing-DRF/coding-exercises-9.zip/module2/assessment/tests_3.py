from unittest import mock

from django.contrib.auth import get_user_model

from assessment.tests_2 import Question2TestCase


class Question3TestCase(Question2TestCase):
    def setUp(self):
        super().setUp()
        get_user_model().objects.create_user(username="test", password="password")

    @mock.patch("time.time")
    def test_logged_in_user_throttling(self, mock_time):
        self.client.login(username="test", password="password")
        self._run_test(mock_time, 100)
