from django.contrib.auth import get_user_model
from django.test import TestCase
from rest_framework.test import APIClient

from assessment.models import Post


class Question4TestCase(TestCase):
    def setUp(self):
        self.user1 = get_user_model().objects.create_user(
            username="test1", password="password"
        )
        self.user2 = get_user_model().objects.create_user(
            username="test2", password="password"
        )

        self.post1 = Post.objects.create(
            title="Post 1", content="Post 1 Content", slug="post-1", author=self.user1
        )
        self.post2 = Post.objects.create(
            title="Post 2", content="Post 2 Content", slug="post-2", author=self.user2
        )
        self.client = APIClient()

    def test_post_endpoints_anonymous(self):
        resp = self.client.get("/api/v1/posts/")
        self.assertEqual(len(resp.json()), 2)
        detail_resp = self.client.get(f"/api/v1/posts/{self.post1.id}/")
        self.assertEqual(detail_resp.status_code, 200)

        detail_resp = self.client.get(f"/api/v1/posts/{self.post2.id}/")
        self.assertEqual(detail_resp.status_code, 200)

    def test_post_endpoints_logged_in(self):
        self.client.login(username="test1", password="password")
        resp = self.client.get("/api/v1/posts/")
        self.assertEqual(len(resp.json()), 1)
        self.assertEqual(resp.json()[0]["id"], self.post1.id)

        detail_resp = self.client.get(f"/api/v1/posts/{self.post1.id}/")
        self.assertEqual(detail_resp.status_code, 200)

        detail_resp = self.client.get(f"/api/v1/posts/{self.post2.id}/")
        self.assertEqual(detail_resp.status_code, 404)

        self.client.logout()

        self.client.login(username="test2", password="password")
        resp = self.client.get("/api/v1/posts/")
        self.assertEqual(len(resp.json()), 1)
        self.assertEqual(resp.json()[0]["id"], self.post2.id)

        detail_resp = self.client.get(f"/api/v1/posts/{self.post1.id}/")
        self.assertEqual(detail_resp.status_code, 404)

        detail_resp = self.client.get(f"/api/v1/posts/{self.post2.id}/")
        self.assertEqual(detail_resp.status_code, 200)
