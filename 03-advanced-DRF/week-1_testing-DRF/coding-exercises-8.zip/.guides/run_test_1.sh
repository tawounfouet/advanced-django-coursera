#!/bin/bash

cd module1
python3 manage.py test_assessment 1