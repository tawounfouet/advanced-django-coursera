from rest_framework import viewsets

from assessment.models import Post
from assessment.serializers import PostSerializer


class PostViewSet(viewsets.ModelViewSet):
    queryset = Post.objects.all()
    serializer_class = PostSerializer
