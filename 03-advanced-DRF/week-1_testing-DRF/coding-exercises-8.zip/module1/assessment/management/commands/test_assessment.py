import sys

from django.core.management.base import BaseCommand
from django.test.runner import DiscoverRunner


class Command(BaseCommand):
    def add_arguments(self, parser):
        parser.add_argument("questions", nargs="*", type=int)

    def handle(self, *args, **options):
        question_numbers = options["questions"] or list(range(1, 6))

        test_files = [f"assessment.questions.question_{q}" for q in question_numbers]

        test_runner = DiscoverRunner(exclude_tags="assessment")

        failures = test_runner.run_tests(test_files)
        sys.exit(bool(failures))
