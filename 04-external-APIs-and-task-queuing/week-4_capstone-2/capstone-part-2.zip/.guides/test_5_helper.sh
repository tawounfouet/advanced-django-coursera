#!/bin/bash

cd movie-night/module4/movienight
python3 manage.py test tests.tests_5