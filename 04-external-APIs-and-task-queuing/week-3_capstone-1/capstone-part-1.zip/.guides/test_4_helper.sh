#!/bin/bash

cd movie-night/module3/movienight
python3 manage.py test tests.tests_4