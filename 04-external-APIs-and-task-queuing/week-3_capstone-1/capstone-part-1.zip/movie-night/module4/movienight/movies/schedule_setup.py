def schedule_setup():
    pass
