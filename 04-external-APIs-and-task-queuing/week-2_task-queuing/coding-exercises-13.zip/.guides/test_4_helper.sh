#!/bin/bash

cd module2
python3 manage.py test books.tests_4