from unittest import mock

from django.conf import settings
from django.test import TestCase


class Question1TestCase(TestCase):
    def test_api_key_set(self):
        self.assertEqual(settings.MBS_API_KEY, "ABC123")

    @mock.patch("my_book_store.django_client.MyBookStoreClient")
    def test_get_client(self, mock_mbs_client):
        from my_book_store.django_client import get_client_from_settings

        old_key = settings.MBS_API_KEY
        settings.MBS_API_KEY = mock.MagicMock()
        client = get_client_from_settings()
        self.assertEqual(mock_mbs_client.return_value, client)
        mock_mbs_client.assert_called_with(settings.MBS_API_KEY)
        settings.MBS_API_KEY = old_key
