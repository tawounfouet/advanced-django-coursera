from django.db import models


class Author(models.Model):
    name = models.TextField(unique=True)


class Book(models.Model):
    title = models.TextField()
    isbn = models.CharField(max_length=13, unique=True)
    author = models.ForeignKey(Author, on_delete=models.PROTECT)
