from django.test import TestCase

from my_book_store.client import MBSAuthor, MBSBook


class Question3TestCase(TestCase):
    def test_mbs_book_model(self):
        data = {
            "author": "My Test Author",
            "title": "My Great Title",
            "isbn": "1111111111111",
        }

        book = MBSBook(data)
        self.assertIsInstance(book.author, MBSAuthor)
        self.assertEqual(book.author.name, "My Test Author")

        self.assertEqual(book.title, "My Great Title")
        self.assertEqual(book.isbn, "1111111111111")
