from django.test import TestCase

from my_book_store.client import MBSAuthor, MBSBook, MyBookStoreClient


class Question4TestCase(TestCase):
    def test_client_with_bad_auth(self):
        client = MyBookStoreClient("aaaa111")
        with self.assertRaises(ValueError):
            client.get_books()

    def test_client_response(self):
        client = MyBookStoreClient("ABC123")
        books = client.get_books()
        self.assertEqual(len(books), 4)

        for b in books:
            self.assertIsInstance(b, MBSBook)
            self.assertIsInstance(b.author, MBSAuthor)
