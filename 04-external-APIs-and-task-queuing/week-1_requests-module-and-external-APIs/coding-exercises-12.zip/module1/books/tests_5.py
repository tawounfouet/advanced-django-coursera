from django.test import TestCase

from books.mbs_integration import get_and_save
from books.models import Book, Author


class Question5Case(TestCase):
    def test_get_and_save(self):
        get_and_save()

        self.assertEqual(Book.objects.all().count(), 4)
        self.assertEqual(Author.objects.all().count(), 3)
        from my_book_store.client import MyBookStoreClient

        for book in MyBookStoreClient.data:
            b = Book.objects.get(title=book["title"], isbn=book["isbn"])
            self.assertEqual(b.author.name, book["author"])
