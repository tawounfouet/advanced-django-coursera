from django.test import TestCase

from my_book_store.client import MBSAuthor


class Question2TestCase(TestCase):
    def test_mbs_author_model(self):
        author_name = "My Test Name"

        author = MBSAuthor(author_name)
        self.assertEqual(author_name, author.name)
