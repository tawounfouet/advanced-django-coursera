#!/bin/bash

cd module1
python3 manage.py test books.tests_2