from django.test import TestCase
from rest_framework import serializers

from assessment.serializers import AppointmentRequestSerializer, validate_full_name


class Question2TestCase(TestCase):
    def test_validate_full_name_good(self):
        """Test that the validator does not raise a ValidationError for a valid value."""
        validate_full_name("good name")

    def test_validate_full_name_bad(self):
        with self.assertRaises(serializers.ValidationError):
            validate_full_name("nospaceshere")

    def test_serializer_valid(self):
        s = AppointmentRequestSerializer(
            data={
                "stylist_name": "good name",
                "start_datetime": "2021-12-25 17:12:34Z",
                "session_length": 30,
            }
        )
        self.assertTrue(s.is_valid())

    def test_serializer_invalid(self):
        s = AppointmentRequestSerializer(
            data={
                "stylist_name": "badname",
                "start_datetime": "2021-12-25 17:12:34Z",
                "session_length": 30,
            }
        )
        self.assertFalse(s.is_valid())
        self.assertEqual(s.errors["stylist_name"][0].code, "invalid")

    def test_serializer_invalid_length(self):
        s = AppointmentRequestSerializer(
            data={
                "stylist_name": ("x" * 35) + " " + ("y" * 35),
                "start_datetime": "2021-12-25 17:12:34Z",
                "session_length": 30,
            }
        )
        self.assertFalse(s.is_valid())
        self.assertEqual(s.errors["stylist_name"][0].code, "max_length")
