from datetime import datetime

from django.test import TestCase
from pytz import UTC
from rest_framework import serializers

from assessment.models import AppointmentRequest
from assessment.serializers import AppointmentRequestSerializer


class Question1TestCase(TestCase):
    def test_serializer_fields(self):
        self.assertTrue(len(AppointmentRequestSerializer._declared_fields), 3)
        self.assertTrue(
            isinstance(
                AppointmentRequestSerializer._declared_fields["stylist_name"],
                serializers.CharField,
            )
        )
        self.assertTrue(
            isinstance(
                AppointmentRequestSerializer._declared_fields["start_datetime"],
                serializers.DateTimeField,
            )
        )
        self.assertTrue(
            isinstance(
                AppointmentRequestSerializer._declared_fields["session_length"],
                serializers.IntegerField,
            )
        )

    def test_create(self):
        s = AppointmentRequestSerializer(
            data={
                "stylist_name": "Bradford Randleson",
                "start_datetime": "2021-12-25 17:12:34Z",
                "session_length": 60,
            }
        )

        self.assertTrue(s.is_valid())

        ar = s.save()

        self.assertEqual(ar.stylist_name, "Bradford Randleson")
        self.assertEqual(
            ar.start_datetime, datetime(2021, 12, 25, 17, 12, 34, tzinfo=UTC)
        )
        self.assertEqual(ar.session_length, 60)

    def test_update(self):
        ar = AppointmentRequest("Craig Blunce", datetime.now(UTC), 20)

        s = AppointmentRequestSerializer(
            ar,
            data={
                "stylist_name": "Morton Fenderson",
                "start_datetime": "2021-03-27 19:13:54Z",
                "session_length": 5,
            },
        )

        self.assertTrue(s.is_valid())

        ar2 = s.save()
        self.assertIs(ar, ar2)
        self.assertEqual(ar2.stylist_name, "Morton Fenderson")
        self.assertEqual(
            ar2.start_datetime, datetime(2021, 3, 27, 19, 13, 54, tzinfo=UTC)
        )
        self.assertEqual(ar2.session_length, 5)

    def test_create_with_default(self):
        s = AppointmentRequestSerializer(
            data={
                "stylist_name": "Bradford Randleson",
                "start_datetime": "2021-12-25 17:12:34Z",
            }
        )

        self.assertTrue(s.is_valid())

        ar = s.save()

        self.assertEqual(ar.stylist_name, "Bradford Randleson")
        self.assertEqual(
            ar.start_datetime, datetime(2021, 12, 25, 17, 12, 34, tzinfo=UTC)
        )
        self.assertEqual(ar.session_length, 30)

    def test_create_with_errors(self):
        s = AppointmentRequestSerializer(
            data={"stylist_name": ("x" * 35) + " " + ("y" * 35), "session_length": 4}
        )
        self.assertFalse(s.is_valid())
        self.assertEqual(s.errors["stylist_name"][0].code, "max_length")
        self.assertEqual(s.errors["start_datetime"][0].code, "required")
        self.assertEqual(s.errors["session_length"][0].code, "min_value")

        s = AppointmentRequestSerializer(
            data={
                "stylist_name": "short name",
                "start_datetime": "2021-12-25 17:12:34Z",
                "session_length": 61,
            }
        )
        self.assertFalse(s.is_valid())
        self.assertEqual(s.errors["session_length"][0].code, "max_value")
