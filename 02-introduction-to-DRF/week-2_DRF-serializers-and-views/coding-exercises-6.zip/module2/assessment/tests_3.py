from django.test import TestCase
from rest_framework import serializers

from assessment.serializers import AppointmentRequestSerializer, validate_full_name


class Question3TestCase(TestCase):
    def test_validate_session_length_method(self):
        s = AppointmentRequestSerializer()
        self.assertEqual(s.validate_session_length(11), 10)
        self.assertEqual(s.validate_session_length(44), 40)
        self.assertEqual(s.validate_session_length(59), 55)

    def test_validate_full_name_bad(self):
        with self.assertRaises(serializers.ValidationError):
            validate_full_name("nospaceshere")

    def test_serializer_valid(self):
        s = AppointmentRequestSerializer(
            data={
                "stylist_name": "good name",
                "start_datetime": "2021-12-25 17:12:34Z",
                "session_length": 36,
            }
        )
        self.assertTrue(s.is_valid())
        self.assertEqual(s.validated_data["session_length"], 35)
