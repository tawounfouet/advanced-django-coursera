from django.test import TestCase
from rest_framework import generics

from assessment.models import Stylist
from assessment.serializers import StylistSerializer
from assessment.views import StylistList, StylistDetail


class Question5TestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.jane = Stylist.objects.create(
            name="Jane Dermina", speciality="cut", accepting_new_clients=False
        )
        cls.phil = Stylist.objects.create(
            name="Phil Hunting", speciality="dye", accepting_new_clients=True
        )
        cls.roscoe = Stylist.objects.create(
            name="Roscoe Blavo", speciality="shave", accepting_new_clients=False
        )

    def test_list_class_setup(self):
        self.assertTrue(issubclass(StylistList, generics.ListCreateAPIView))
        self.assertEqual(StylistList.serializer_class, StylistSerializer)
        self.assertEqual(list(StylistList.queryset.all()), list(Stylist.objects.all()))

        self.assertTrue(
            issubclass(StylistDetail, generics.RetrieveUpdateDestroyAPIView)
        )
        self.assertEqual(StylistDetail.serializer_class, StylistSerializer)
        self.assertEqual(
            list(StylistDetail.queryset.all()), list(Stylist.objects.all())
        )
