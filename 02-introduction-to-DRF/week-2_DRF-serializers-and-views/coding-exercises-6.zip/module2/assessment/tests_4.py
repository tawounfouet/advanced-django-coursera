from django.test import TestCase
from rest_framework import serializers

from assessment.models import Stylist
from assessment.serializers import StylistSerializer


class Question4TestCase(TestCase):
    def test_serializer_class_setup(self):
        self.assertTrue(issubclass(StylistSerializer, serializers.ModelSerializer))
        # self.assertTrue(
        #     issubclass(StylistSerializer.Meta, serializers.SerializerMetaclass)
        # )
        self.assertEqual(StylistSerializer.Meta.model, Stylist)
        self.assertEqual(StylistSerializer.Meta.fields, "__all__")
