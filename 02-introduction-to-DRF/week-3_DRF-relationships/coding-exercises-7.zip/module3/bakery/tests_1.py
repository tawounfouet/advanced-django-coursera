import base64
import json

from django.contrib.auth.models import User
from django.test import TestCase
from rest_framework.authtoken.models import Token


class Question1TestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.USERNAME = "testuser"
        cls.EMAIL = "testuser@example.com"
        cls.PASSWORD = "testpassword123!@#"

        u = User.objects.create_user(cls.USERNAME, cls.EMAIL, cls.PASSWORD)

        cls.token = Token.objects.create(user=u).key

    def test_unauthenticated_get(self):
        resp = self.client.get("/api/v1/question1/")
        data = json.loads(resp.content)
        self.assertEqual(data["username"], "")

    def test_session_auth_get(self):
        self.client.login(username=self.USERNAME, password=self.PASSWORD)
        resp = self.client.get("/api/v1/question1/")
        data = json.loads(resp.content)
        self.assertEqual(data["username"], self.USERNAME)

    def test_basic_auth_get(self):
        credentials = base64.b64encode(
            f"{self.USERNAME}:{self.PASSWORD}".encode("ascii")
        )
        resp = self.client.get(
            "/api/v1/question1/", HTTP_AUTHORIZATION=b"Basic " + credentials
        )
        data = json.loads(resp.content)
        self.assertEqual(data["username"], self.USERNAME)

    def test_token_auth_get(self):
        resp = self.client.get(
            "/api/v1/question1/",
            HTTP_AUTHORIZATION=b"Token " + self.token.encode("ascii"),
        )
        data = json.loads(resp.content)
        self.assertEqual(data["username"], self.USERNAME)
