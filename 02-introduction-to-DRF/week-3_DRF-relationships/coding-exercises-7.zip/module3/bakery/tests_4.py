import json

from django.test import TestCase

from bakery.management.commands.create_fixtures import Command
from bakery.models import Customer


class Question4TestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        # set up test data with same fixture
        c = Command()
        c.handle()
        cls.orders = c.orders

    def test_embedded_address(self):
        # need to find the IDs because they aren't always the same
        bill = Customer.objects.get(name="Bill")
        address = bill.address

        resp = self.client.get(f"/api/v1/customers/{bill.id}")
        data = json.loads(resp.content)
        self.assertEqual(data["address"]["street_name"], address.street_name)
        self.assertEqual(data["address"]["city"], address.city)
