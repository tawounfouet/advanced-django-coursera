import json

from django.test import TestCase

from bakery.management.commands.create_fixtures import Command
from bakery.models import Customer, Address


class Question5TestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        # set up test data with same fixture
        c = Command()
        c.handle()
        cls.orders = c.orders

    def test_embedded_address_create(self):
        customer = {
            "name": "Eddy",
            "email": "eddy@example.com",
            "address": {"street_name": "API Street", "city": "API City"},
        }

        self.client.post(
            f"/api/v1/customers/",
            json.dumps(customer),
            content_type="application/json",
        )

        eddy = Customer.objects.get(name="Eddy", email="eddy@example.com")
        self.assertEqual(eddy.address.street_name, "API Street")
        self.assertEqual(eddy.address.city, "API City")

    def test_embedded_address_update(self):
        # need to find the IDs because they aren't always the same
        original_address_count = Address.objects.all().count()
        chris = Customer.objects.get(name="Chris")
        original_street_name = chris.address.street_name
        original_city = chris.address.city

        resp = self.client.get(f"/api/v1/customers/{chris.id}")
        data = json.loads(resp.content)

        data["address"]["street_name"] = "API Updated Street Name"
        data["address"]["city"] = "API Updated City"

        self.client.put(
            f"/api/v1/customers/{chris.id}",
            json.dumps(data),
            content_type="application/json",
        )

        # should create a new address object
        chris.refresh_from_db()
        chris.address.refresh_from_db()
        self.assertEqual(chris.address.street_name, "API Updated Street Name")
        self.assertEqual(chris.address.city, "API Updated City")

        new_address_count = Address.objects.all().count()
        self.assertEqual(new_address_count, original_address_count + 1)

        data["address"]["street_name"] = original_street_name
        data["address"]["city"] = original_city

        self.client.put(
            f"/api/v1/customers/{chris.id}",
            json.dumps(data),
            content_type="application/json",
        )

        # it shouldn't create another address when setting back
        chris.refresh_from_db()
        chris.address.refresh_from_db()
        self.assertEqual(chris.address.street_name, original_street_name)
        self.assertEqual(chris.address.city, original_city)
        new_address_count = Address.objects.all().count()
        self.assertEqual(new_address_count, original_address_count + 1)
