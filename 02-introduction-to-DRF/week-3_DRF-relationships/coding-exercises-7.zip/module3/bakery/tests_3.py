import json

from django.test import TestCase

from bakery.management.commands.create_fixtures import Command


class Question3TestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        # set up test data with same fixture
        c = Command()
        c.handle()
        cls.orders = c.orders

    def test_slug_field_read(self):
        resp = self.client.get(f"/api/v1/orders/{self.orders[0].id}")
        data = json.loads(resp.content)
        self.assertEqual(len(data["food"]), 2)
        self.assertEqual(set(data["food"]), {"Cake", "Donut"})

    def test_slug_field_update(self):
        get_resp = self.client.get(f"/api/v1/orders/{self.orders[0].id}")
        data = json.loads(get_resp.content)

        data["food"] = ["Donut", "Eclair"]

        self.client.put(
            f"/api/v1/orders/{self.orders[0].id}",
            json.dumps(data),
            content_type="application/json",
        )

        get_resp = self.client.get(f"/api/v1/orders/{self.orders[0].id}")
        data = json.loads(get_resp.content)

        self.assertEqual(len(data["food"]), 2)
        self.assertEqual(set(data["food"]), {"Donut", "Eclair"})
