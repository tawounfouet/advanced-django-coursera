import json
from unittest import mock

from django.contrib.auth.models import User
from django.test import TestCase
from rest_framework.authtoken.models import Token
from rest_framework.permissions import SAFE_METHODS
from rest_framework.request import Request

from bakery.api.permissions import InversePermissions


class Question2TestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.USERNAME = "testuser"
        cls.EMAIL = "testuser@example.com"
        cls.PASSWORD = "testpassword123!@#"

        # make them a staff user so we can use the Django admin login form
        u = User.objects.create_user(cls.USERNAME, cls.EMAIL, cls.PASSWORD)

        cls.token = Token.objects.create(user=u).key

    def test_unauthenticated_get_detail(self):
        resp = self.client.get("/api/v1/name-and-count/2/")
        self.assertEqual(resp.status_code, 401)

    def test_authenticated_get_detail(self):
        resp = self.client.get(
            "/api/v1/name-and-count/2/",
            HTTP_AUTHORIZATION=b"Token " + self.token.encode("ascii"),
        )
        data = json.loads(resp.content)
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(len(data), 2)

    def test_unauthenticated_get_list(self):
        resp = self.client.get("/api/v1/name-and-count/")
        self.assertEqual(resp.status_code, 401)

    def test_authenticated_get_list(self):
        resp = self.client.get(
            "/api/v1/name-and-count/",
            HTTP_AUTHORIZATION=b"Token " + self.token.encode("ascii"),
        )
        data = json.loads(resp.content)
        self.assertEqual(len(data), 5)

    def test_unauthenticated_post(self):
        resp = self.client.post(
            "/api/v1/name-and-count/",
            json.dumps({"name": "F", "count": 6}),
            content_type="application/json",
        )
        data = json.loads(resp.content)
        self.assertEqual(data["name"], "F")
        self.assertEqual(data["count"], 6)

    def test_authenticated_post(self):
        resp = self.client.post(
            "/api/v1/name-and-count/",
            json.dumps({"name": "F", "count": 6}),
            HTTP_AUTHORIZATION=b"Token " + self.token.encode("ascii"),
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 403)

    def test_unauthenticated_put(self):
        resp = self.client.put(
            "/api/v1/name-and-count/7/",
            json.dumps({"name": "G", "count": 7}),
            content_type="application/json",
        )
        data = json.loads(resp.content)
        self.assertEqual(data["name"], "G")
        self.assertEqual(data["count"], 7)

    def test_authenticated_put(self):
        resp = self.client.post(
            "/api/v1/name-and-count/7/",
            json.dumps({"name": "G", "count": 7}),
            content_type="application/json",
            HTTP_AUTHORIZATION=b"Token " + self.token.encode("ascii"),
        )
        self.assertEqual(resp.status_code, 403)

    def test_unauthenticated_delete(self):
        resp = self.client.delete("/api/v1/name-and-count/4/")
        self.assertEqual(resp.status_code, 204)

    def test_authenticated_delete(self):
        resp = self.client.delete(
            "/api/v1/name-and-count/4/",
            HTTP_AUTHORIZATION=b"Token " + self.token.encode("ascii"),
        )
        self.assertEqual(resp.status_code, 403)

    def test_inverse_permissions(self):
        ip = InversePermissions()

        user = mock.Mock(spec=User)
        user.is_anonymous = False
        user.is_authenticated = True

        user_anon = mock.Mock(spec=User)
        user_anon.is_anonymous = True
        user_anon.is_authenticated = False

        req = mock.Mock(spec=Request)
        for u in (user, user_anon):
            for method in ("GET", "POST", "PUT", "OPTIONS", "HEAD", "DELETE"):
                req.method = method
                req.user = u

                perm = ip.has_permission(req, None)
                self.assertEqual(perm, u.is_anonymous is (method not in SAFE_METHODS))

                object_perm = ip.has_object_permission(req, None, None)
                self.assertEqual(
                    object_perm, u.is_anonymous is (method not in SAFE_METHODS)
                )
