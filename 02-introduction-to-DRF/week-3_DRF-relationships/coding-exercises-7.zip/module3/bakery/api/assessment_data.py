# This file does not need to be changed


class NameAndCount:
    def __init__(self, name, count):
        self.name = name
        self.count = count


test_data = [
    NameAndCount("a", 1),
    NameAndCount("b", 2),
    NameAndCount("c", 3),
    NameAndCount("d", 4),
    NameAndCount("e", 5),
]
