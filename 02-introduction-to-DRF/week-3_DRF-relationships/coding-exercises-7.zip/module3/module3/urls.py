"""module3 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

import bakery.api.assessment_views
from bakery.api.assessment_views import Question1View
from bakery.api import views as api_views

api_patterns = [
    path("question1/", Question1View.as_view()),
    path("name-and-count/", api_views.NameAndCountView.as_view()),
    path("name-and-count/<int:pk>/", api_views.NameAndCountView.as_view()),
    path(
        "addresses/",
        bakery.api.assessment_views.AddressListView.as_view(),
        name="address_list",
    ),
    path(
        "addresses/<int:pk>",
        bakery.api.assessment_views.AddressDetailView.as_view(),
        name="address_detail",
    ),
    path("food/", bakery.api.assessment_views.FoodListView.as_view(), name="food_list"),
    path(
        "food/<int:pk>",
        bakery.api.assessment_views.FoodDetailView.as_view(),
        name="food_detail",
    ),
    path(
        "orders/",
        bakery.api.assessment_views.OrderListView.as_view(),
        name="order_list",
    ),
    path(
        "orders/<int:pk>",
        bakery.api.assessment_views.OrderDetailView.as_view(),
        name="order_detail",
    ),
    path(
        "customers/",
        bakery.api.assessment_views.CustomerListView.as_view(),
        name="customer_list",
    ),
    path(
        "customers/<int:pk>",
        bakery.api.assessment_views.CustomerDetailView.as_view(),
        name="customer_detail",
    ),
]

urlpatterns = [path("admin/", admin.site.urls), path("api/v1/", include(api_patterns))]
