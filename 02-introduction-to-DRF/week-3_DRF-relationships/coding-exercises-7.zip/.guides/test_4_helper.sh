#!/bin/bash

cd module3
python3 manage.py test bakery.tests_4