#!/bin/bash

cd module1
python3 manage.py test assessment.tests_5