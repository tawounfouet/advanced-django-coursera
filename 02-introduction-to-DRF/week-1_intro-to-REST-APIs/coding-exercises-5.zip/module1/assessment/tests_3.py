import json

from django.http import JsonResponse, Http404
from django.test import TestCase

from assessment.models import Fruit, fruit_to_dict
from assessment.views import handle_list_get, handle_detail_get


class Question3TestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.banana = Fruit.objects.create(name="Banana", price=10, stock_level=5)
        cls.apple = Fruit.objects.create(name="Apple", price=15, stock_level=4)
        cls.lemon = Fruit.objects.create(name="Lemon", price=20, stock_level=3)
        cls.peach = Fruit.objects.create(name="Peach", price=1, stock_level=1)
        cls.fruits = [cls.banana, cls.apple, cls.lemon, cls.peach]

    def test_list(self):
        fruits_response = handle_list_get()
        self.assertIsInstance(fruits_response, JsonResponse)
        decoded_body = json.loads(fruits_response.content)
        fruits_as_dict = list(map(fruit_to_dict, self.fruits))
        self.assertEqual(fruits_as_dict, decoded_body["data"])

    def test_detail(self):
        fruit_response = handle_detail_get(self.lemon.pk)
        self.assertIsInstance(fruit_response, JsonResponse)
        lemon = json.loads(fruit_response.content)
        self.assertEqual(fruit_to_dict(self.lemon), lemon)

    def test_404(self):
        with self.assertRaises(Http404):
            handle_detail_get(100)
