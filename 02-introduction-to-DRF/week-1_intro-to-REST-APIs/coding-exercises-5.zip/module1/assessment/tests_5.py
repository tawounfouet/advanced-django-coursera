import json

from django.http import Http404
from django.test import TestCase

from assessment.models import Fruit
from assessment.views import handle_detail_put, handle_detail_delete


class Question55TestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.mango = Fruit.objects.create(name="Mango", price=20, stock_level=10)

    def test_update(self):
        body = json.dumps({"name": "Peach", "price": 100, "stock_level": 10})

        resp = handle_detail_put(self.mango.pk, body)

        f = Fruit.objects.get(pk=self.mango.pk)
        self.assertEqual(f.price, 100)
        self.assertEqual(f.stock_level, 10)

        self.assertEqual(resp.status_code, 204)

    def test_delete(self):
        resp = handle_detail_delete(self.mango.pk)
        self.assertEqual(resp.status_code, 204)
        self.assertEqual(Fruit.objects.filter(pk=self.mango.pk).count(), 0)

    def test_update_non_existent(self):
        body = json.dumps({"name": "Peach", "price": 100, "stock_level": 10})

        with self.assertRaises(Http404):
            handle_detail_put(100, body)

    def test_delete_non_existent(self):
        with self.assertRaises(Http404):
            handle_detail_delete(100)
