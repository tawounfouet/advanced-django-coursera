# It is not necessary to change this file
from django.contrib import admin

from assessment.models import Fruit

admin.site.register(Fruit)
