import json

from django.test import TestCase

from assessment.models import Fruit
from assessment.views import handle_list_post


class Question4TestCase(TestCase):
    def test_create(self):
        body = json.dumps({"name": "Mango", "price": 100, "stock_level": 10})

        resp = handle_list_post(body)

        f = Fruit.objects.get(name="Mango")
        self.assertEqual(f.price, 100)
        self.assertEqual(f.stock_level, 10)

        self.assertEqual(resp.status_code, 201)
        self.assertEqual(resp.headers["Location"], f"/api/fruits/{f.pk}/")
