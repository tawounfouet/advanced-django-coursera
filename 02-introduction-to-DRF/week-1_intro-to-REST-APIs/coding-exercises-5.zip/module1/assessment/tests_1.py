from unittest import mock

from django.test import TestCase

from assessment.views import fruit_list


class Question1TestCase(TestCase):
    @mock.patch("assessment.views.handle_list_get")
    def test_fruit_list_get_call(self, mock_list_get):
        request = mock.Mock()
        request.method = "GET"
        resp = fruit_list(request)
        mock_list_get.assert_called_with()
        self.assertEqual(resp, mock_list_get.return_value)

    @mock.patch("assessment.views.handle_list_post")
    def test_fruit_list_post_call(self, mock_list_post):
        request = mock.Mock()
        request.method = "POST"
        resp = fruit_list(request)
        mock_list_post.assert_called_with(request.body)
        self.assertEqual(resp, mock_list_post.return_value)

    def test_fruit_list_other_call(self):
        request = mock.Mock()
        request.method = "PUT"
        resp = fruit_list(request)
        self.assertEqual(resp.status_code, 405)
        allowed_methods = set(
            map(lambda s: s.strip(), resp.headers["Allow"].split(","))
        )
        self.assertEqual(allowed_methods, {"GET", "POST"})
