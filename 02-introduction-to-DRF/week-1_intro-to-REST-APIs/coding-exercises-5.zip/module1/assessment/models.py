# It is not necessary to change this file
from django.db import models


class Fruit(models.Model):
    class Meta:
        ordering = ["pk"]

    name = models.CharField(max_length=20, unique=True)
    price = models.PositiveIntegerField()
    stock_level = models.PositiveIntegerField()


def fruit_to_dict(fruit):
    return {
        "pk": fruit.pk,
        "name": fruit.name,
        "price": fruit.price,
        "stock_level": fruit.stock_level,
    }
