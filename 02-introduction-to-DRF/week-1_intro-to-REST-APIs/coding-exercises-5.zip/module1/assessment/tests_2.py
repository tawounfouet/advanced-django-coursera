import random
from unittest import mock

from django.test import TestCase

from assessment.views import fruit_detail


class Question2TestCase(TestCase):
    @mock.patch("assessment.views.handle_detail_get")
    def test_fruit_detail_get_call(self, mock_detail_get):
        pk = random.randint(1, 50)
        request = mock.Mock()
        request.method = "GET"
        resp = fruit_detail(request, pk)
        mock_detail_get.assert_called_with(pk)
        self.assertEqual(resp, mock_detail_get.return_value)

    @mock.patch("assessment.views.handle_detail_put")
    def test_fruit_detail_put_call(self, mock_detail_put):
        pk = random.randint(1, 50)
        request = mock.Mock()
        request.method = "PUT"
        resp = fruit_detail(request, pk)
        mock_detail_put.assert_called_with(pk, request.body)
        self.assertEqual(resp, mock_detail_put.return_value)

    @mock.patch("assessment.views.handle_detail_delete")
    def test_fruit_detail_delete_call(self, mock_detail_delete):
        pk = random.randint(1, 50)
        request = mock.Mock()
        request.method = "DELETE"
        resp = fruit_detail(request, pk)
        mock_detail_delete.assert_called_with(pk)
        self.assertEqual(resp, mock_detail_delete.return_value)

    def test_fruit_detail_other_call(self):
        request = mock.Mock()
        request.method = "POST"
        resp = fruit_detail(request, 100)
        self.assertEqual(resp.status_code, 405)
        allowed_methods = set(
            map(lambda s: s.strip(), resp.headers["Allow"].split(","))
        )
        self.assertEqual(allowed_methods, {"GET", "PUT", "DELETE"})
