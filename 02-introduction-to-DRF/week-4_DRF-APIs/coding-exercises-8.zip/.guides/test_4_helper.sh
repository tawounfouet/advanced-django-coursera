#!/bin/bash

cd module4
python3 manage.py test bakery.tests_4