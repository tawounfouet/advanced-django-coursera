from django.contrib.auth.models import User
from django.core.management.base import BaseCommand
from django.db import IntegrityError

from bakery.models import Customer, Food, Order, Address


class Command(BaseCommand):
    help = "Set up test fixtures"

    def handle(self, *args, **options):
        try:
            User.objects.create_user("testuser", "test@example.com", "password")
        except IntegrityError:
            pass

        ann_address = Address.objects.get_or_create(
            street_name="Test Street", city="Alphania"
        )[0]
        bill_address = Address.objects.get_or_create(
            street_name="Fake Road", city="Bravoria"
        )[0]
        chris_address = Address.objects.get_or_create(
            street_name="Madeup Lane", city="Charlievile"
        )[0]
        dan_address = Address.objects.get_or_create(
            street_name="Noexist Crescent", city="Delturius"
        )[0]

        ann = Customer.objects.get_or_create(
            name="Ann", email="ann@example.com", defaults={"address": ann_address}
        )[0]
        bill = Customer.objects.get_or_create(
            name="Bill", email="bill@example.com", defaults={"address": bill_address}
        )[0]
        chris = Customer.objects.get_or_create(
            name="Chris", email="chris@example.com", defaults={"address": chris_address}
        )[0]
        dan = Customer.objects.get_or_create(
            name="Dan", email="dan@example.com", defaults={"address": dan_address}
        )[0]

        cake = Food.objects.get_or_create(name="Cake", price=1)[0]
        donut = Food.objects.get_or_create(name="Donut", price=2)[0]
        eclair = Food.objects.get_or_create(name="Eclair", price=3)[0]
        pie = Food.objects.get_or_create(name="Pie", price=4)[0]

        order1 = Order.objects.get_or_create(customer=ann)[0]
        order1.food.set({cake, donut})
        order1.save()

        order2 = Order.objects.get_or_create(customer=bill)[0]
        order2.food.set({eclair, donut})
        order2.save()

        order3 = Order.objects.get_or_create(customer=chris)[0]
        order3.food.set({cake, pie})
        order3.save()

        order4 = Order.objects.get_or_create(customer=dan)[0]
        order4.food.set({pie, donut})
        order4.save()
        self.orders = order1, order2, order3, order4
