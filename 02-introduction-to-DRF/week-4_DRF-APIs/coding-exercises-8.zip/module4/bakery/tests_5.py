import json

from django.test import TestCase

from bakery.management.commands.create_fixtures import Command


class Question5TestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        # set up test data with same fixture
        c = Command()
        c.handle()

    def test_customer_order_list(self):
        customers_resp = self.client.get("/api/v1/customers/")
        for customer in json.loads(customers_resp.content):
            resp = self.client.get(f"/api/v1/customers/{customer['id']}/orders/")
            data = json.loads(resp.content)
            for order in data:
                self.assertIn("food", order)
                self.assertIn("id", order)
                self.assertEqual(order["customer"], customer["id"])
