import json

from django.test import TestCase

from bakery.api.assessment_serializers import OrderListSerializer, OrderDetailSerializer
from bakery.api.views import OrderViewSet
from bakery.management.commands.create_fixtures import Command


class Question4TestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        # set up test data with same fixture
        c = Command()
        c.handle()

    def test_order_listing(self):
        resp = self.client.get("/api/v1/orders/")
        data = json.loads(resp.content)
        for order in data:
            self.assertNotIn("food", order)

    def test_order_detail(self):
        resp = self.client.get("/api/v1/orders/")
        data = json.loads(resp.content)

        for order in data:
            detail_resp = self.client.get(f"/api/v1/orders/{order['id']}/")
            detail_data = json.loads(detail_resp.content)
            self.assertIn("food", detail_data)
            self.assertIsInstance(detail_data["food"], list)

    def test_get_serializer_method(self):
        vs = OrderViewSet()
        for action in [
            "list",
            "create",
            "retrieve",
            "update",
            "partial_update",
            "destroy",
        ]:
            if action == "list":
                expected_class = OrderListSerializer
            else:
                expected_class = OrderDetailSerializer
            vs.action = action
            self.assertEqual(vs.get_serializer_class(), expected_class)
