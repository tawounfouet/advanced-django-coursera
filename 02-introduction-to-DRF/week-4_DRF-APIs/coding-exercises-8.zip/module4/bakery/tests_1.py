from html.parser import HTMLParser

from django.test import TestCase


class DrfAdminHtmlParser(HTMLParser):
    found_branding_link = False
    in_branding_link = False
    branding_link_content = ""

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "a" and attrs.get("class") == "navbar-brand":
            if self.found_branding_link:
                raise ValueError("Found navbar-brand more than once")

            self.found_branding_link = True
            self.in_branding_link = True
            if attrs.get("href") != "/":
                raise ValueError("Branding link does not link to /")

    def handle_endtag(self, tag):
        if self.in_branding_link and tag == "a":
            self.in_branding_link = False
            if self.branding_link_content.strip() != "Bakery API":
                raise ValueError("Content of branding link is not Bakery API")

    def handle_data(self, data):
        if self.in_branding_link:
            self.branding_link_content += data


class Question1TestCase(TestCase):
    def test_branding_name(self):
        resp = self.client.get("/api/v1/question1/", HTTP_ACCEPT="text/html")
        parser = DrfAdminHtmlParser()
        parser.feed(resp.content.decode("utf8"))
        self.assertTrue(parser.found_branding_link)
