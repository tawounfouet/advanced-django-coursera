# This file does not need to be edited
from rest_framework import views
from rest_framework.response import Response


class Question1View(views.APIView):
    def get(self, request):
        return Response({"status": "OK"})
