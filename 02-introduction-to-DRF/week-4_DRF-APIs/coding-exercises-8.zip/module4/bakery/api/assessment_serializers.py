# This file does not need to be edited

from rest_framework import serializers

from bakery.models import Address, Food, Order, Customer


class AddressSerializer(serializers.ModelSerializer):
    class Meta:
        model = Address
        fields = "__all__"

    def create(self, validated_data):
        return Address.objects.get_or_create(**validated_data)[0]

    def update(self, instance, validated_data):
        return Address.objects.get_or_create(**validated_data)[0]


class FoodSerializer(serializers.ModelSerializer):
    class Meta:
        model = Food
        fields = "__all__"


class OrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = Order
        fields = ["id", "customer"]


# An alias for Question 3 or 4, it doesn't matter which of these names is used
OrderListSerializer = OrderSerializer


class OrderDetailSerializer(serializers.ModelSerializer):
    food = serializers.SlugRelatedField(
        slug_field="name", many=True, queryset=Food.objects.all()
    )

    class Meta:
        model = Order
        fields = "__all__"


class CustomerSerializer(serializers.ModelSerializer):
    address = AddressSerializer()

    class Meta:
        model = Customer
        fields = "__all__"

    def create(self, validated_data):
        address_dict = validated_data.pop("address")
        address = Address.objects.get_or_create(**address_dict)[0]
        validated_data["address"] = address
        return super(CustomerSerializer, self).create(validated_data)

    def update(self, instance, validated_data):
        address_dict = validated_data.pop("address")
        super(CustomerSerializer, self).update(instance, validated_data)

        if (
            instance.address.street_name != address_dict["street_name"]
            or instance.address.city != address_dict["city"]
        ):
            address = Address.objects.get_or_create(**address_dict)[0]
            instance.address = address
            instance.save()

        return instance
