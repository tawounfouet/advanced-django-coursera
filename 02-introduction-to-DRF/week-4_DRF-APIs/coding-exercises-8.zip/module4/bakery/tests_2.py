from django.test import TestCase
from django.urls import URLResolver
from rest_framework.routers import DefaultRouter

from module4.urls import router, api_patterns


class Question2TestCase(TestCase):
    expected = {
        ("bakery.api.views.OrderViewSet", "order-list", "^orders/$"),
        (
            "bakery.api.views.OrderViewSet",
            "order-list",
            r"^orders\.(?P<format>[a-z0-9]+)/?$",
        ),
        (
            "bakery.api.views.OrderViewSet",
            "order-detail",
            "^orders/(?P<pk>[^/.]+)/$",
        ),
        (
            "bakery.api.views.OrderViewSet",
            "order-detail",
            r"^orders/(?P<pk>[^/.]+)\.(?P<format>[a-z0-9]+)/?$",
        ),
        ("bakery.api.views.AddressViewSet", "address-list", "^addresses/$"),
        (
            "bakery.api.views.AddressViewSet",
            "address-list",
            r"^addresses\.(?P<format>[a-z0-9]+)/?$",
        ),
        (
            "bakery.api.views.AddressViewSet",
            "address-detail",
            "^addresses/(?P<pk>[^/.]+)/$",
        ),
        (
            "bakery.api.views.AddressViewSet",
            "address-detail",
            r"^addresses/(?P<pk>[^/.]+)\.(?P<format>[a-z0-9]+)/?$",
        ),
        ("bakery.api.views.FoodViewSet", "food-list", "^food/$"),
        (
            "bakery.api.views.FoodViewSet",
            "food-list",
            r"^food\.(?P<format>[a-z0-9]+)/?$",
        ),
        ("bakery.api.views.FoodViewSet", "food-detail", "^food/(?P<pk>[^/.]+)/$"),
        (
            "bakery.api.views.FoodViewSet",
            "food-detail",
            r"^food/(?P<pk>[^/.]+)\.(?P<format>[a-z0-9]+)/?$",
        ),
        ("bakery.api.views.CustomerViewSet", "customer-list", "^customers/$"),
        (
            "bakery.api.views.CustomerViewSet",
            "customer-list",
            r"^customers\.(?P<format>[a-z0-9]+)/?$",
        ),
        (
            "bakery.api.views.CustomerViewSet",
            "customer-detail",
            "^customers/(?P<pk>[^/.]+)/$",
        ),
        (
            "bakery.api.views.CustomerViewSet",
            "customer-detail",
            r"^customers/(?P<pk>[^/.]+)\.(?P<format>[a-z0-9]+)/?$",
        ),
        ("rest_framework.routers.APIRootView", "api-root", "^$"),
        (
            "rest_framework.routers.APIRootView",
            "api-root",
            r"^\.(?P<format>[a-z0-9]+)/?$",
        ),
    }

    def test_router_class(self):
        self.assertIsInstance(router, DefaultRouter)

    def test_router_setup(self):
        actual = set()

        for url in router.urls:
            if url.name == "customer-orders":
                continue
            pattern = (url.lookup_str, url.name, str(url.pattern))
            actual.add(pattern)
            self.assertIn(pattern, self.expected)
        self.assertEqual(len(actual), len(self.expected))

    def test_inclusion_in_api_patterns(self):
        actual = set()

        for url in api_patterns:
            if isinstance(url, URLResolver):
                for sub_url in url.url_patterns:
                    if sub_url.name == "customer-orders":
                        continue
                    pattern = (sub_url.lookup_str, sub_url.name, str(sub_url.pattern))
                    actual.add(pattern)

        self.assertEqual(actual, self.expected)
