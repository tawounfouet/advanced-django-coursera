from django.test import TestCase

from bakery.api.assessment_serializers import (
    OrderListSerializer,
    AddressSerializer,
    CustomerSerializer,
    FoodSerializer,
)
from bakery.api.views import OrderViewSet, AddressViewSet, CustomerViewSet, FoodViewSet


class Question3TestCase(TestCase):
    def test_serializers_on_viewsets(self):
        self.assertEqual(OrderViewSet.serializer_class, OrderListSerializer)
        self.assertEqual(AddressViewSet.serializer_class, AddressSerializer)
        self.assertEqual(CustomerViewSet.serializer_class, CustomerSerializer)
        self.assertEqual(FoodViewSet.serializer_class, FoodSerializer)
