#!/bin/bash

cd module4
python3 manage.py test assessment.tests_5