from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit
from django.test import TestCase
from django_registration.forms import RegistrationForm

from assessment.forms import CustomRegistrationForm
from assessment.models import User


class Question4TestCase(TestCase):
    def test_registration_form_helper_attributes(self):
        crf = CustomRegistrationForm()

        self.assertTrue(hasattr(crf, "helper"))
        self.assertIsInstance(crf.helper, FormHelper)
        self.assertTrue(len(crf.helper.inputs), 1)
        submit_button = crf.helper.inputs[0]
        self.assertIsInstance(submit_button, Submit)
        self.assertEqual(submit_button.name, "submit")
        self.assertEqual(submit_button.value, "Register")

    def test_registration_form_meta(self):
        self.assertEqual(CustomRegistrationForm.Meta.model, User)
        self.assertTrue(issubclass(CustomRegistrationForm.Meta, RegistrationForm.Meta))
