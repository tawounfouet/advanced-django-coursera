from django.contrib.auth import get_user_model
from django.db import models
from django.test import TestCase

OneToOneFieldOriginal = models.OneToOneField


class MockOneToOneField(OneToOneFieldOriginal):
    def __init__(self, to, *args, **kwargs):
        if to != "assessment.User":
            raise ValueError(
                "User/Profile relationship must be constructed with string for 'to' argument."
            )
        super(MockOneToOneField, self).__init__(to, *args, **kwargs)


class Question2TestCase(TestCase):
    def test_profile_model_definition(self):
        models.OneToOneField = MockOneToOneField
        from assessment.models import Profile

        self.assertIsInstance(Profile.user.field, OneToOneFieldOriginal)
        models.OneToOneField = OneToOneFieldOriginal

    def test_profile_user_relationship(self):
        from assessment.models import Profile

        u = get_user_model().objects.create_user(
            username="testuser", password="password"
        )
        Profile.objects.create(location="home", user=u)

        u1 = get_user_model().objects.first()
        self.assertEqual(u1.profile.location, "home")
