from html.parser import HTMLParser

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit
from django.test import TestCase
from django_registration.forms import RegistrationForm

from assessment.forms import CustomRegistrationForm
from assessment.models import User


class RegisterFormParser(HTMLParser):
    form_ok = False
    username_ok = False
    email_ok = False
    password1_ok = False
    password2_ok = False
    csrf_token_ok = False
    submit_ok = False

    def __init__(self):
        self.rows = []

        super(RegisterFormParser, self).__init__()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)

        if tag == "input":
            name = attrs.get("name")
            type_ = attrs.get("type")
            if name == "csrfmiddlewaretoken":
                self.csrf_token_ok = True
                return

            if name == "username" and type_ == "text":
                self.username_ok = True
                return

            if name == "password1" and type_ == "password":
                self.password1_ok = True
                return

            if name == "password2" and type_ == "password":
                self.password2_ok = True
                return

            if name == "email" and type_ == "email":
                self.email_ok = True
                return

            if type_ == "submit":
                self.submit_ok = True
                return

            return

        if tag == "button" and attrs.get("type") == "submit":
            self.submit_ok = True
            return

        if tag == "form" and attrs.get("method", "").lower() == "post":
            action = attrs.get("action")

            if not action or action == "/accounts/register/":
                self.form_ok = True
            return

    def handle_endtag(self, tag):
        pass

    def error(self, message):
        raise ValueError(message)


class Question5TestCase(TestCase):
    def test_registration_page_content(self):
        resp = self.client.get("/accounts/register/")
        self.assertEqual(resp.status_code, 200)
        parser = RegisterFormParser()
        parser.feed(resp.content.decode("utf8"))
        self.assertTrue(
            parser.form_ok, "<form> is missing or has incorrect method/action elements"
        )
        self.assertTrue(parser.username_ok, "Username input missing/incorrect")
        self.assertTrue(parser.password1_ok, "Password1 input missing/incorrect")
        self.assertTrue(parser.password2_ok, "Password2 input missing/incorrect")
        self.assertTrue(parser.email_ok, "Email input missing/incorrect")
        self.assertTrue(parser.csrf_token_ok, "CSRF token input missing/incorrect")
        self.assertTrue(parser.submit_ok, "Submit button/input missing")

    def test_registration_form_meta(self):
        username = "testuser"
        password = "MySecurePassword1234!@#$"
        email = "user@example.com"

        reg_resp = self.client.post(
            "/accounts/register/",
            {
                "username": username,
                "email": email,
                "password1": password,
                "password2": password,
            },
        )
        self.assertEqual(reg_resp.status_code, 302)
        self.assertTrue(reg_resp.headers["Location"], "/accounts/register/complete/")

        login_resp = self.client.post(
            "/accounts/login/", {"username": username, "password": password}
        )
        self.assertEqual(login_resp.status_code, 302)
        self.assertEqual(login_resp.headers["Location"], "/accounts/profile/")
