from html.parser import HTMLParser

from django.contrib.auth import get_user_model
from django.test import TestCase


class LoginFormParser(HTMLParser):
    form_ok = False
    username_ok = False
    password_ok = False
    csrf_token_ok = False
    submit_ok = False

    def __init__(self):
        self.rows = []

        super(LoginFormParser, self).__init__()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)

        if tag == "input":
            name = attrs.get("name")
            type_ = attrs.get("type")
            if name == "csrfmiddlewaretoken":
                self.csrf_token_ok = True
                return

            if name == "username" and type_ == "text":
                self.username_ok = True
                return

            if name == "password" and type_ == "password":
                self.password_ok = True
                return

            if type_ == "submit":
                self.submit_ok = True
                return

            return

        if tag == "button" and attrs.get("type") == "submit":
            self.submit_ok = True
            return

        if tag == "form" and attrs.get("method", "").lower() == "post":
            action = attrs.get("action")

            if not action or action == "/accounts/login/":
                self.form_ok = True
            return

    def handle_endtag(self, tag):
        pass

    def error(self, message):
        raise ValueError(message)


class Question3TestCase(TestCase):
    def test_login_page_content(self):
        resp = self.client.get("/accounts/login/")
        self.assertEqual(resp.status_code, 200)
        parser = LoginFormParser()
        parser.feed(resp.content.decode("utf8"))
        self.assertTrue(
            parser.form_ok, "<form> is missing or has incorrect method/action elements"
        )
        self.assertTrue(parser.username_ok, "Username input missing/incorrect")
        self.assertTrue(parser.password_ok, "Password input missing/incorrect")
        self.assertTrue(parser.csrf_token_ok, "CSRF token input missing/incorrect")
        self.assertTrue(parser.submit_ok, "Submit button/input missing")

    def test_logging_in(self):
        get_user_model().objects.create_user(username="testuser", password="password")

        bad_resp = self.client.post(
            "/accounts/login/", {"username": "bad", "password": "bad"}
        )
        self.assertEqual(bad_resp.status_code, 200)
        self.assertIn(b"Please enter a correct username and password", bad_resp.content)

        good_resp = self.client.post(
            "/accounts/login/", {"username": "testuser", "password": "password"}
        )

        self.assertEqual(good_resp.status_code, 302)
        self.assertEqual(good_resp.headers["Location"], "/accounts/profile/")
