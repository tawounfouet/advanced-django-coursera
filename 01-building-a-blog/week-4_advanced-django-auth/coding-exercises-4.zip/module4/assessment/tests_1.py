from django.conf import settings
from django.contrib.auth import get_user_model
from django.test import TestCase

from assessment.models import User


class Question1TestCase(TestCase):
    def test_auth_user_model(self):
        self.assertEqual(settings.AUTH_USER_MODEL, "assessment.User")
        self.assertEqual(get_user_model(), User)
