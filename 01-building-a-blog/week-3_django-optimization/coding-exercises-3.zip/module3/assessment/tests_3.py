import re
from time import time
from unittest import mock

from django.test import TestCase

start_time = time()


def extract_times(resp):
    content = resp.content.decode("utf8").replace("\n", "")
    current_time_str = re.search(r"Is (.*)</h1>", content)
    cached_time_str = re.search(r"Was (.*)</h2>", content)
    return current_time_str.group(1), cached_time_str.group(1)


class Question3TestCase(TestCase):
    @mock.patch("time.time")
    def test_template_caching(self, mock_time):
        mock_time.return_value = start_time
        resp1 = self.client.get("/question3/")
        resp2 = self.client.get("/question3/")

        current_time_1, cached_time_1 = extract_times(resp1)
        current_time_2, cached_time_2 = extract_times(resp2)

        self.assertNotEqual(current_time_1, current_time_2)
        self.assertEqual(cached_time_1, cached_time_2)

        # advance time by 1:19, cache should still be valid
        mock_time.return_value = start_time + 119

        resp3 = self.client.get("/question3/")
        current_time_3, cached_time_3 = extract_times(resp3)

        self.assertNotEqual(current_time_1, current_time_3)
        self.assertEqual(cached_time_1, cached_time_3)

        # advance time by 1:21, cache should have expired
        mock_time.return_value = start_time + 121
        resp4 = self.client.get("/question3/")

        current_time_4, cached_time_4 = extract_times(resp4)

        self.assertNotEqual(current_time_1, current_time_4)
        self.assertNotEqual(cached_time_1, cached_time_4)
