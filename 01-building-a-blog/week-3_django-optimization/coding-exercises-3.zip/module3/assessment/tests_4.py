from unittest import mock

from django.test import TestCase

from assessment.models import Resource, get_test_resources
from assessment.views import question4


class Question4TestCase(TestCase):
    def test_resources_bulk_create(self):
        mock_bulk_create = mock.MagicMock()
        Resource.objects.bulk_create = mock_bulk_create
        test_resources = get_test_resources()
        question4(None)
        self.assertEqual(mock_bulk_create.call_count, 1)
        self.assertEqual(
            test_resources[0].name, mock_bulk_create.call_args[0][0][0].name
        )
        self.assertEqual(
            test_resources[0].cost, mock_bulk_create.call_args[0][0][0].cost
        )
        self.assertEqual(
            test_resources[1].name, mock_bulk_create.call_args[0][0][1].name
        )
        self.assertEqual(
            test_resources[1].cost, mock_bulk_create.call_args[0][0][1].cost
        )
        self.assertEqual(
            test_resources[2].name, mock_bulk_create.call_args[0][0][2].name
        )
        self.assertEqual(
            test_resources[2].cost, mock_bulk_create.call_args[0][0][2].cost
        )
