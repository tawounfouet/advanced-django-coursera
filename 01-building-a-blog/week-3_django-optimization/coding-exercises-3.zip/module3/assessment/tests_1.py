from unittest import mock

from django.test import TestCase

from time import time

start_time = time()


class Question1TestCase(TestCase):
    @mock.patch("time.time")
    def test_view_caching(self, mock_time):
        mock_time.return_value = start_time
        resp1 = self.client.get("/question1/")
        resp2 = self.client.get("/question1/")

        self.assertEqual(resp1.content, resp2.content)

        # advance time by 1:19, cache should still be valid
        mock_time.return_value = start_time + 119

        resp3 = self.client.get("/question1/")
        self.assertEqual(resp1.content, resp3.content)

        # advance time by 1:21, cache should have expired
        mock_time.return_value = start_time + 121
        resp4 = self.client.get("/question1/")

        self.assertNotEqual(resp1.content, resp4.content)
