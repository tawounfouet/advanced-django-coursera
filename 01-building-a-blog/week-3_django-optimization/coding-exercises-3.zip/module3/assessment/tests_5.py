from unittest import mock

from django.test import TestCase

from assessment.models import Resource, get_test_resources
from assessment.views import question5


class Question5TestCase(TestCase):
    def test_resources_bulk_update(self):
        mock_bulk_update = mock.MagicMock()
        Resource.objects.bulk_update = mock_bulk_update
        test_resources = get_test_resources()
        question5(None)
        self.assertEqual(mock_bulk_update.call_count, 1)
        self.assertEqual(
            test_resources[0].name, mock_bulk_update.call_args[0][0][0].name
        )
        self.assertEqual(
            test_resources[0].cost + 10, mock_bulk_update.call_args[0][0][0].cost
        )
        self.assertEqual(
            test_resources[1].name, mock_bulk_update.call_args[0][0][1].name
        )
        self.assertEqual(
            test_resources[1].cost + 10, mock_bulk_update.call_args[0][0][1].cost
        )
        self.assertEqual(
            test_resources[2].name, mock_bulk_update.call_args[0][0][2].name
        )
        self.assertEqual(
            test_resources[2].cost + 10, mock_bulk_update.call_args[0][0][2].cost
        )
        self.assertEqual(["cost"], mock_bulk_update.call_args[0][1])
