from unittest import mock

from django.contrib.auth.models import User
from django.test import TestCase, Client

from time import time

start_time = time()


class Question2TestCase(TestCase):
    @mock.patch("time.time")
    def test_view_caching(self, mock_time):
        mock_time.return_value = start_time
        test_username = "testuser1"
        test_password = "testpassword1234!@#$"
        User.objects.create_user(test_username, password=test_password)

        client1 = Client()
        client1.post(
            "/accounts/login/", {"username": test_username, "password": test_password}
        )
        resp1 = client1.get("/question2/")
        resp2 = client1.get("/question2/")
        self.assertIn(b"testuser", resp1.content)
        self.assertEqual(resp1.content, resp2.content)

        client2 = Client()
        resp3 = client2.get("/question2/")
        self.assertIn(b"AnonymousUser", resp3.content)

        mock_time.return_value = start_time + 119

        resp4 = client1.get("/question2/")
        self.assertEqual(resp1.content, resp4.content)
        mock_time.return_value = start_time + 121

        resp5 = client1.get("/question2/")
        self.assertIn(b"testuser", resp5.content)
        self.assertNotEqual(resp5.content, resp1.content)
