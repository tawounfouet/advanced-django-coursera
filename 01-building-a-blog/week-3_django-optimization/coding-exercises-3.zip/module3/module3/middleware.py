from django.utils.deprecation import MiddlewareMixin


class CookieCleanMiddleware(MiddlewareMixin):
    @staticmethod
    def process_request(request):
        cookie_header = request.META.get("HTTP_COOKIE")
        if not cookie_header:
            return

        new_cookie = ""

        for cookie in cookie_header.split(";"):
            cookie_name, cookie_value = cookie.split("=")
            cookie_name = cookie_name.strip()
            if cookie_name not in ("AWSALB", "AWSALBCORS"):
                new_cookie += cookie_name + "=" + cookie_value + "; "

        new_cookie = new_cookie.strip()

        request.META["HTTP_COOKIE"] = new_cookie
